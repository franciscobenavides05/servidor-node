export interface ApiPaths {
  email: string;
}
