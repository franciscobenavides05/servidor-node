export const messages = {
  SERVER_ERROR: 'Something went wrong. Talking the Administrator',
  SEND_EMAIL: 'Mensaje enviado con éxito',
  SEND_EMAIL_ERROR: 'Error al enviar el correo electrónico',
}
